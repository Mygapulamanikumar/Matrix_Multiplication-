function createMatrixTable(rows, columns, matrixId) {
    const table = document.getElementById(matrixId);
    table.innerHTML = ''; // Clear previous content

    for (let i = 0; i < rows; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < columns; j++) {
            const cell = document.createElement('td');
            const input = document.createElement('input');
            input.type = 'number';
            input.classList.add('matrix-cell');
            cell.appendChild(input);
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
}

// Function to update matrix dimensions based on user input
function updateMatrixDimensions() {
    const rowsA = parseInt(document.getElementById('rowsA').value);
    const columnsA = parseInt(document.getElementById('columnsA').value);
    const rowsB = parseInt(document.getElementById('rowsB').value);
    const columnsB = parseInt(document.getElementById('columnsB').value);

    createMatrixTable(rowsA, columnsA, 'matrixA');
    createMatrixTable(rowsB, columnsB, 'matrixB');
}
function multiplyMatrices(matrixA, matrixB) {
    const rowsA = matrixA.length;
    const columnsA = matrixA[0].length;
    const rowsB = matrixB.length;
    const columnsB = matrixB[0].length;

    if (columnsA !== rowsB || columnsB !== rowsA) {
        alert('Matrix multiplication cannot be performed with the given dimensions.');
        return;
    }
    // Initialize the result matrix
    const result = [];
    for (let i = 0; i < rowsA; i++) {
        result[i] = [];
        for (let j = 0; j < columnsB; j++) {
            result[i][j] = 0;
        }
    }

    // Perform multiplication
    for (let i = 0; i < rowsA; i++) {
        for (let j = 0; j < columnsB; j++) {
            for (let k = 0; k < columnsA; k++) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }

    return result;
}


 function calculate() {
        // Retrieve values from input fields
        const matrixAValues = [];
        const matrixBValues = [];

        const matrixACells = document.querySelectorAll('#matrixA input');
        const matrixBCells = document.querySelectorAll('#matrixB input');

        matrixACells.forEach(cell => matrixAValues.push(Number(cell.value)));
        matrixBCells.forEach(cell => matrixBValues.push(Number(cell.value)));

        // Convert 1D arrays to 2D matrices
        const rowsA = parseInt(document.getElementById('rowsA').value);
        const columnsA = parseInt(document.getElementById('columnsA').value);
        const rowsB = parseInt(document.getElementById('rowsB').value);
        const columnsB = parseInt(document.getElementById('columnsB').value);
        if (columnsA !== rowsB || columnsB !== rowsA) {
            alert('Matrix multiplication cannot be performed with the given dimensions.');
            return;
        }
        const matrixA = [];
        const matrixB = [];

        for (let i = 0; i < rowsA; i++) {
            matrixA.push(matrixAValues.slice(i * columnsA, (i + 1) * columnsA));
        }

        for (let i = 0; i < rowsB; i++) {
            matrixB.push(matrixBValues.slice(i * columnsB, (i + 1) * columnsB));
        }

        // Perform matrix multiplication
        const result =multiplyMatrices(matrixA, matrixB);
        displayResult(result);

}
function displayResult(resultMatrix) {
    if (!resultMatrix) {
        document.getElementById('result').innerHTML = "<p>Matrix multiplication cannot be performed with the given dimensions.</p>";
        return;
    }

    let resultHTML = "<h2>Result:</h2><table>";
    for (let i = 0; i < resultMatrix.length; i++) {
        resultHTML += "<tr>";
        for (let j = 0; j < resultMatrix[0].length; j++) {
            resultHTML += "<td>" + resultMatrix[i][j] + "</td>";
        }
        resultHTML += "</tr>";
    }
    resultHTML += "</table>";
    document.getElementById('result').innerHTML = resultHTML;
}

// Attach event listener to calculate button
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('calculateBtn').addEventListener('click', calculate);
});

// Event listeners for matrix dimensions
document.getElementById('rowsA').addEventListener('input', updateMatrixDimensions);
document.getElementById('columnsA').addEventListener('input', updateMatrixDimensions);
document.getElementById('rowsB').addEventListener('input', updateMatrixDimensions);
document.getElementById('columnsB').addEventListener('input', updateMatrixDimensions);
